import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
// �ٷ� â �ߴ� �ڵ�
public class Haksa2 extends JFrame{
	JTextField tfId=null;
	JTextField tfName=null;
	JTextField tfDepartment=null;
	JTextField tfAddress=null;
	
	JTextArea taList=null;
	
	JButton btnInsert=null;
	JButton btnSelect=null;
	JButton btnUpdate=null;
	JButton btnDelete=null;
	JButton btnSearch=null;
	
	Connection conn=null;
	Statement stmt=null;
	
	
	JTable table = null;
	DefaultTableModel model=null;
	
	
	public Haksa2() {
		setTitle("�л����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//db connection
		try {
			//oracle jdbc����̹� �ε�
			Class.forName("oracle.jdbc.driver.OracleDriver");// jdbc driver load
			//Connection
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ora_user","hong");// ����
			System.out.println("����Ϸ�");
			stmt=conn.createStatement();
			}catch(Exception e){
				e.printStackTrace();
		}
		
		//DB Close, �����찡 ����� �� ����
		
		this.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {}

			@Override
			public void windowClosing(WindowEvent e) {
				try {
					if(conn!=null) {
						conn.close();
					}
				}catch(Exception e1) {
					e1.printStackTrace();
				}
				
			}

			@Override
			public void windowClosed(WindowEvent e) {}

			@Override
			public void windowIconified(WindowEvent e) {}

			@Override
			public void windowDeiconified(WindowEvent e) {}

			@Override
			public void windowActivated(WindowEvent e) {}

			@Override
			public void windowDeactivated(WindowEvent e) {}
		});
		
		
		
		
		Container c= getContentPane();
		c.setLayout(new FlowLayout());
		
		
		
		c.add(new JLabel("�й�"));
		this.tfId=new JTextField(14);
		c.add(tfId);
		
		this.btnSearch=new JButton("�˻�");
		c.add(this.btnSearch);
		this.btnSearch.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stmt=conn.createStatement();
					
					//��� �ʱ�ȭ
					
					model.setNumRows(0);
					
					ResultSet rs=stmt.executeQuery("select * from student where id = '"+tfId.getText()+"'");
					
					
					while(rs.next()) {
						
						tfName.setText(rs.getString("name"));
						tfDepartment.setText(rs.getString("dept"));
						tfAddress.setText(rs.getString("Address"));
						String[] row=new String[4];
						row[0]=rs.getString("id");
						row[1]=rs.getString("name");
						row[2]=rs.getString("dept");
						row[3]=rs.getString("address");
						
						model.addRow(row);
						
					}
					rs.close();
					stmt.close();
					 
					
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
		});
		
		
		c.add(new JLabel("�̸�"));
		this.tfName=new JTextField(20);
		c.add(tfName);
		
		c.add(new JLabel("�а�"));
		this.tfDepartment=new JTextField(20);
		c.add(tfDepartment);
		
		c.add(new JLabel("�ּ�"));
		this.tfAddress=new JTextField(20);
		c.add(tfAddress);
		
		
		String[] colName= {"�й�","�̸�","�а�","�ּ�"};//�÷���
		this.model = new DefaultTableModel(colName,0);//�𵥤���
		this.table = new JTable(this.model);//���̺��� �� ����
		this.table.setPreferredScrollableViewportSize(new Dimension(250,150));//���̺� ũ��
		//c.add(this.table);//��ũ���� ����
		c.add(new JScrollPane(this.table));
		// ���̺��� Ư������ �����ؼ� textField�� ���� �Է�
		this.table.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				//�̺�Ʈ�� �߻��� ������Ʈ(table)�� ���Ѵ�.
				table=(JTable)e.getComponent();
				//table�� ���� ���Ѵ�.
				model=(DefaultTableModel)table.getModel();
				// ���� ���õ� ���� �÷��� ���Ѵ�.
				tfId.setText((String)model.getValueAt(table.getSelectedRow(), 0));
				tfName.setText((String)model.getValueAt(table.getSelectedRow(), 1));
				tfDepartment.setText((String)model.getValueAt(table.getSelectedRow(), 2));
				tfAddress.setText((String)model.getValueAt(table.getSelectedRow(), 3));
			}

			@Override
			public void mousePressed(MouseEvent e) {}

			@Override
			public void mouseReleased(MouseEvent e) {}

			@Override
			public void mouseEntered(MouseEvent e) {}

			@Override
			public void mouseExited(MouseEvent e) {}
			
		});
		
		
		
		this.btnInsert=new JButton("���");
		c.add(btnInsert);
		this.btnInsert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// DB����, ������ insert
				if(tfId.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�й��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfName.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�̸��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfDepartment.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�а��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfAddress.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�ּҰ� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else{
					try {
						Statement stmt=conn.createStatement();
						
						stmt.executeUpdate("insert into student values('"+tfId.getText()+"', '"+tfName.getText()+"', '"+tfDepartment.getText()+"', '"+tfAddress.getText()+"')");
						
						model.setNumRows(0);
						ResultSet rs=stmt.executeQuery("select * from student");
						
						
						
						while(rs.next()) {
							
							String[] row=new String[4];
							row[0]=rs.getString("id");
							row[1]=rs.getString("name");
							row[2]=rs.getString("dept");
							row[3]=rs.getString("address");
							
							model.addRow(row);
							
						}
						rs.close();
						stmt.close();
						 
						
					}catch(Exception e1){
						e1.printStackTrace();
					}
				JOptionPane.showMessageDialog(null,"��ϵǾ����ϴ�.");}
			}});
		
		this.btnSelect=new JButton("���");
		c.add(btnSelect);
		this.btnSelect.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Statement stmt=conn.createStatement();
					model.setNumRows(0);
					ResultSet rs=stmt.executeQuery("select * from student");
					
					
					
					while(rs.next()) {
						
						String[] row=new String[4];
						row[0]=rs.getString("id");
						row[1]=rs.getString("name");
						row[2]=rs.getString("dept");
						row[3]=rs.getString("address");
						
						model.addRow(row);
						
					}
						
					
					rs.close();
					stmt.close();
					 
					
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
			
		});
		
		
		this.btnUpdate=new JButton("����");
		c.add(btnUpdate);
		this.btnUpdate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Statement stmt=conn.createStatement();
					
					
					model.setNumRows(0);
					stmt.executeUpdate("update student set name='"+tfName.getText()+"',dept='"+tfDepartment.getText()+"',address='"+tfAddress.getText()+"' where id='"+tfId.getText()+"'");
					
			
					//ta�� ��� �ʱ�ȭ
					
					ResultSet rs=stmt.executeQuery("select * from student where id = '"+tfId.getText()+"'");
					
					
					while(rs.next()) {
					
						String[] row=new String[4];
						row[0]=rs.getString("id");
						row[1]=rs.getString("name");
						row[2]=rs.getString("dept");
						row[3]=rs.getString("address");
						
						model.addRow(row);
						
						
					}
					rs.close();
					stmt.close();
					 
					
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
			
			
		});
		
		
		
		this.btnDelete=new JButton("����");
		add(this.btnDelete);
		this.btnDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int result=JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�?","�˸�",JOptionPane.YES_NO_OPTION);
				System.out.println(result);
				if(result==JOptionPane.YES_OPTION) {
					//����ó��
					try {						
						Statement stmt=conn.createStatement();					
												
						//delete
						
						stmt.executeUpdate("insert into dont_exist_student_bookrent valuses(select * from bookrent where id='"+tfId.getText()+"')"); // �й� ������ ������� ���� ���� ������ �ٸ� ���̺��� ����
						
						stmt.executeUpdate("delete from bookrent where id='"+tfId.getText()+"'"); //�������� ���̺����� �ش� ���� ����
						
						stmt.executeUpdate("delete from student where id='"+tfId.getText()+"'");
												
						//����ʱ�ȭ
						model.setNumRows(0);//���� �� 0						
						
						ResultSet rs=stmt.executeQuery("select * from student");						
						
						while(rs.next()) {
							
							String[] row=new String[3];
							row[0]=rs.getString("id");
							row[1]=rs.getString("name");
							row[2]=rs.getString("dept");
							
							model.addRow(row);
						}	
						rs.close();
						stmt.close();
					
						
					}catch(Exception e1) {
						e1.printStackTrace();
					}
				}
			}});
		
		this.setSize(280, 500);
		this.setVisible(true);
	}



	public static void main(String[] args) {
		new Haksa2();
	}
	
}
