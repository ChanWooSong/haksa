import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Student extends JPanel{
	JTextField tfId=null;
	JTextField tfName=null;
	JTextField tfDepartment=null;
	JTextField tfAddress=null;
	
	JTextArea taList=null;
	
	JButton btnInsert=null;
	JButton btnSelect=null;
	JButton btnUpdate=null;
	JButton btnDelete=null;
	JButton btnSearch=null;
	
	Connection conn=null;
	Statement stmt=null;
	
	
	JTable table = null;
	DefaultTableModel model=null;
	
	
	public Student() {
		
		//db connection
		try {
			//oracle jdbc����̹� �ε�
			Class.forName("oracle.jdbc.driver.OracleDriver");// jdbc driver load
			//Connection
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ora_user","hong");// ����
//			System.out.println("����Ϸ�");
			stmt=conn.createStatement();
			}catch(Exception e){
				e.printStackTrace();
		}
		
		//DB Close, �����찡 ����� �� ����
		
		
		
		
		
		
		add(new JLabel("�й�"));
		this.tfId=new JTextField(15);
		add(tfId);
		
		this.btnSearch=new JButton("�˻�");
		add(this.btnSearch);
		this.btnSearch.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					stmt=conn.createStatement();
					ResultSet rs1=stmt.executeQuery("select id from student where id = '"+tfId.getText()+"'");
					String[] a=new String[1];
					while(rs1.next()) {
					a[0]=	rs1.getString("id");
					}
					 

					if(tfId.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "�й��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
						
					}
					else if(tfId.getText().equals(a[0])) {
					
					model.setNumRows(0);	
					ResultSet rs=stmt.executeQuery("select * from student where id = '"+tfId.getText()+"'");
						
					
					
					//��� �ʱ�ȭ
					
					
					
					
					while(rs.next()) {
						
						tfName.setText(rs.getString("name"));
						tfDepartment.setText(rs.getString("dept"));
						tfAddress.setText(rs.getString("Address"));
						String[] row=new String[4];
						row[0]=rs.getString("id");
						row[1]=rs.getString("name");
						row[2]=rs.getString("dept");
						row[3]=rs.getString("address");
						
						model.addRow(row);
						
						

					}
					rs.close();
										}
					else {
						JOptionPane.showMessageDialog(null, "��ġ�ϴ� �й��� �����ϴ�.","���",JOptionPane.ERROR_MESSAGE);
						
					
				}
					
					stmt.close();
					
					rs1.close();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
		});
		
		
		add(new JLabel("�̸�"));
		this.tfName=new JTextField(21);
		add(tfName);
		
		add(new JLabel("�а�"));
		this.tfDepartment=new JTextField(21);
		add(tfDepartment);
		
		add(new JLabel("�ּ�"));
		this.tfAddress=new JTextField(21);
		add(tfAddress);
		
		String[] colName= {"�й�","�̸�","�а�","�ּ�"};//�÷���
		this.model = new DefaultTableModel(colName,0);//�𵥤���
		this.table = new JTable(this.model);//���̺��� �� ����
		this.table.setPreferredScrollableViewportSize(new Dimension(250,150));//���̺� ũ��
		//add(this.table);//��ũ���� ����
		add(new JScrollPane(this.table));
		// ���̺��� Ư������ �����ؼ� textField�� ���� �Է�
		this.table.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				//�̺�Ʈ�� �߻��� ������Ʈ(table)�� ���Ѵ�.
				table=(JTable)e.getComponent();
				//table�� ���� ���Ѵ�.
				model=(DefaultTableModel)table.getModel();
				// ���� ���õ� ���� �÷��� ���Ѵ�.
				tfId.setText((String)model.getValueAt(table.getSelectedRow(), 0));
				tfName.setText((String)model.getValueAt(table.getSelectedRow(), 1));
				tfDepartment.setText((String)model.getValueAt(table.getSelectedRow(), 2));
				tfAddress.setText((String)model.getValueAt(table.getSelectedRow(), 3));
			}

			@Override
			public void mousePressed(MouseEvent e) {}

			@Override
			public void mouseReleased(MouseEvent e) {}

			@Override
			public void mouseEntered(MouseEvent e) {}

			@Override
			public void mouseExited(MouseEvent e) {}
			
		});
		
		
		
		this.btnInsert=new JButton("���");
		add(btnInsert);
		this.btnInsert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// DB����, ������ insert
				if(tfId.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�й��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfName.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�̸��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfDepartment.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�а��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else if(tfAddress.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�ּҰ� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
				}else{
					
					
					try {
						Statement stmt=conn.createStatement();
						ResultSet rs1=stmt.executeQuery("select id from student where id = '"+tfId.getText()+"'");
						String[] a=new String[1];
						while(rs1.next()) {
						a[0]=	rs1.getString("id");
						}
						 

						if(tfId.getText().equals(a[0])) {
							JOptionPane.showMessageDialog(null, "�̹� ��ϵ� �й��Դϴ�.","���",JOptionPane.ERROR_MESSAGE);
						}
						else {
						
							int result=JOptionPane.showConfirmDialog(null, "�й��� ��ϵ� �������� ������ �����Ͻðڽ��ϱ�?","�˸�",JOptionPane.YES_NO_OPTION);
							if(result==JOptionPane.YES_OPTION) {
								
								stmt.executeUpdate("insert into student values('"+tfId.getText()+"', '"+tfName.getText()+"', '"+tfDepartment.getText()+"', '"+tfAddress.getText()+"')");
								stmt.executeUpdate("insert into bookrent valuses(select * from dont_exist_student_bookrent where id='"+tfId.getText()+"')"); // �й� �Է½� ����� ���� ���� ������  ���� ���� ���̺��� ����
								stmt.executeUpdate("delete from dont_exist_student_bookrent where id='"+tfId.getText()+"'");// ������� ������ �����ƴ� ���� ���� ���̺����� ����
								
							}else if (result==JOptionPane.NO_OPTION) {
								stmt.executeUpdate("insert into student values('"+tfId.getText()+"', '"+tfName.getText()+"', '"+tfDepartment.getText()+"', '"+tfAddress.getText()+"')");
								
							}
								
						
						model.setNumRows(0);
						ResultSet rs=stmt.executeQuery("select * from student");
						
						
						
						while(rs.next()) {
							
							String[] row=new String[4];
							row[0]=rs.getString("id");
							row[1]=rs.getString("name");
							row[2]=rs.getString("dept");
							row[3]=rs.getString("address");
							
							model.addRow(row);
							
						}
						rs.close();
						stmt.close();
						JOptionPane.showMessageDialog(null,"��ϵǾ����ϴ�.");
						}
//						else {
//							JOptionPane.showMessageDialog(null,"��ϵǾ����ϴ�.");
//							}
						
						
					}catch(Exception e1){
						e1.printStackTrace();
					}
				}
			}});
		
		this.btnSelect=new JButton("���");
		add(btnSelect);
		this.btnSelect.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","ora_user","hong");
					
					Statement stmt=conn.createStatement();
					model.setNumRows(0);
					ResultSet rs=stmt.executeQuery("select * from student");
					
					
					
					while(rs.next()) {
						
						String[] row=new String[4];
						row[0]=rs.getString("id");
						row[1]=rs.getString("name");
						row[2]=rs.getString("dept");
						row[3]=rs.getString("address");
						
						model.addRow(row);
						
					}
						
					
					rs.close();
					stmt.close();
					
					}
				catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
			
		});
		
		
		this.btnUpdate=new JButton("����");
		add(btnUpdate);
		this.btnUpdate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Statement stmt=conn.createStatement();
					ResultSet rs1=stmt.executeQuery("select id from student where id = '"+tfId.getText()+"'");
					String[] a=new String[1];
					while(rs1.next()) {
					a[0]=	rs1.getString("id");
					}
					 

					if(tfId.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "�й��� �Էµ��� �ʾҽ��ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
					 }
					else if(tfId.getText().equals(a[0])) {
						
						
						
					
						
						
						model.setNumRows(0);
						stmt.executeUpdate("update student set name='"+tfName.getText()+"',dept='"+tfDepartment.getText()+"',address='"+tfAddress.getText()+"' where id='"+tfId.getText()+"'");
						
				
						//ta�� ��� �ʱ�ȭ
						
						ResultSet rs=stmt.executeQuery("select * from student where id = '"+tfId.getText()+"'");
						
						
						while(rs.next()) {
						
							String[] row=new String[4];
							row[0]=rs.getString("id");
							row[1]=rs.getString("name");
							row[2]=rs.getString("dept");
							row[3]=rs.getString("address");
							
							model.addRow(row);
							
							
						}
						rs.close();
						stmt.close();
						
					 } 
					else {
						
						JOptionPane.showMessageDialog(null, "�й��� ������ �� �����ϴ�.","Message",JOptionPane.ERROR_MESSAGE);
						
						
					}
					
						
					
					
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}
			
			
			
		});
		
		
		
		this.btnDelete=new JButton("����");
		add(btnDelete);
		this.btnDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				if(tfId.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "�й��� �Էµ��� �ʾҽ��ϴ�.","���",JOptionPane.ERROR_MESSAGE);
				}else {
				int result=JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�?","�˸�",JOptionPane.YES_NO_OPTION);
				
				if(result==JOptionPane.YES_OPTION) {
						

					try {
						
						
						Statement stmt=conn.createStatement();

						stmt.executeUpdate("insert into dont_exist_student_bookrent valuses(select * from bookrent where id='"+tfId.getText()+"')"); // �й� ������ ������� ���� ���� ������ �ٸ� ���̺��� ����
//						
						stmt.executeUpdate("delete from bookrent where id='"+tfId.getText()+"'"); //�������� ���̺����� �ش� ���� ����
//						
						stmt.executeUpdate("delete from student where id='"+tfId.getText()+"'");
						model.setNumRows(0);
						
						ResultSet rs=stmt.executeQuery("select * from student");
						
						//ta�� ��� �ʱ�ȭ
						
						
						
						
						
						
						while(rs.next()) {
						
							String[] row=new String[4];
							row[0]=rs.getString("id");
							row[1]=rs.getString("name");
							row[2]=rs.getString("dept");
							row[3]=rs.getString("address");
							
							model.addRow(row);
							
							
						}
						rs.close();
						stmt.close();	
//					}
					}catch(Exception e1){
						e1.printStackTrace();
					}
				}
//				JOptionPane.showConfirmDialog(parentComponent, message)
			}}});
		
		this.setSize(290,400);
		this.setVisible(true);
	}
	
}
